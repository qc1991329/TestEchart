create trigger "tib_bss_log_renew"
	before insert
	on BSS_LOG_RENEW
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  Column "LOG_ID" uses sequence SEQ_BSS_LOG
    select SEQ_BSS_LOG.NEXTVAL INTO :new.LOG_ID from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
