create trigger "tib_command_log"
	before insert
	on COMMAND_LOG_20131227
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  Column "CIL_ID" uses sequence TRI_COMMOND_LOG_20131227
    select TRI_COMMOND_LOG_20131227.NEXTVAL INTO :new.CIL_ID from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
