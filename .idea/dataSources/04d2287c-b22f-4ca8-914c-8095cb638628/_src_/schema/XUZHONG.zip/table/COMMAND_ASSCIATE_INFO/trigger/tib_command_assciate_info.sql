create trigger "tib_command_assciate_info"
	before insert
	on COMMAND_ASSCIATE_INFO
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  Column "CAI_ID" uses sequence SEQ_CAI_ID
    select SEQ_CAI_ID.NEXTVAL INTO :new.CAI_ID from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
