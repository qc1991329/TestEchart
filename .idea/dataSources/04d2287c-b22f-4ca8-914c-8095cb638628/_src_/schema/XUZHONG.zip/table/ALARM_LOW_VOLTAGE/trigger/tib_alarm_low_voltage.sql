create trigger "tib_alarm_low_voltage"
	before insert
	on ALARM_LOW_VOLTAGE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  Column "ALV_ID" uses sequence SEQ_ALV_ID
    select SEQ_ALV_ID.NEXTVAL INTO :new.ALV_ID from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
