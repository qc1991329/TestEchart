create trigger "tib_vehicle_unable_locate"
	before insert
	on ALARM_UNABLE_LOCATE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  Column "AUL_ID" uses sequence SEQ_AUL_ID
    select SEQ_AUL_ID.NEXTVAL INTO :new.AUL_ID from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
