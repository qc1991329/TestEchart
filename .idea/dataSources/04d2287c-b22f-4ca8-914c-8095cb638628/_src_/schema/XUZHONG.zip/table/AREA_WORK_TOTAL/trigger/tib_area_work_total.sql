create trigger "tib_area_work_total"
	before insert
	on AREA_WORK_TOTAL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  Column "AT_ID" uses sequence SEQ_AWT_ID2
    select SEQ_AWT_ID2.NEXTVAL INTO :new.AT_ID from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
