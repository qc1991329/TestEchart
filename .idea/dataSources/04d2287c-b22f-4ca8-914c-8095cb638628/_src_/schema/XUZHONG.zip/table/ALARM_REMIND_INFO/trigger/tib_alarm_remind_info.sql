create trigger "tib_alarm_remind_info"
	before insert
	on ALARM_REMIND_INFO
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  Column "ARI_ID" uses sequence SEQ_ARI_ID
    select SEQ_ARI_ID.NEXTVAL INTO :new.ARI_ID from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
