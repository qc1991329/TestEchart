create trigger "tib_alarm_remind_unsold"
	before insert
	on ALARM_REMIND_UNSOLD
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  Column "ARU_ID" uses sequence SEQ_ARU_ID
    select SEQ_ARU_ID.NEXTVAL INTO :new.ARU_ID from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
