create view VCPICNTOUT as
(
select VI_PROVINCE,VI_CITY,VMI_NAME,CNT from
(
select vi_province,vi_city,vmi_name,TO_CHAR(count(1)) as cnt
from vcpi
where 1=1
and vi_wartanty_end<=sysdate
group by vi_province,vi_city,vmi_name
)
)

