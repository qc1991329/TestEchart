create view VCPI as
(
select
vi.vi_vin_code,vi.vi_model,vi.vi_province,vi.vi_city
,vm.vmi_name
,vi.vi_wartanty_start
--,vi.vi_wartanty_end  //如果质保结束日期为空 开始时间加两年
,NVL(vi.vi_wartanty_end, ADD_MONTHS(vi.vi_wartanty_start ,24)) as vi_wartanty_end
from vehicle_info vi
left join vehicle_model_info vm on vi.vi_model=vm.vmi_id
where 1=1
and vi.vi_wartanty_start is not null --质保开始时间不为空
and vi.vi_province is not  null
and vi.vi_city is not null
and vi.vi_province <> 'null'
and vm.vmi_name is not null
)

