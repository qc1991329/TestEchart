create view V_NOT_MAINTENANCE_COUNT as
SELECT vi.DI_SAP_CODE, count(1) NOT_MAINTENANCE_COUNT
               FROM NOT_MAINTENANCE nm
              --inner join MOVE_VEHICLE_INFO mvi
                 --on mvi.MVI_VIN = nm.NM_VIN
               left join VEHICLE_INFO vi
                 on nm.nm_vin = vi.vi_vin_code
              where (nm.NM_MAINTENANCE_TIME >= nm.NM_INSERT_TIME AND
                    vi.VI_TERMINAL_CODE IS NOT NULL AND
                    (vi.VI_GPSTIME IS NULL OR
                    (nm.NM_MAINTENANCE_TIME - vi.VI_GPSTIME) > 3))
              group by vi.DI_SAP_CODE

